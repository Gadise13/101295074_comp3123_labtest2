
import React from 'react';

function WeatherDetails({ data }) {
  const { main, wind, clouds } = data;
  return (
    <div className="weather-details">
      <p>Humidity: {main?.humidity}%</p>
      <p>Pressure: {main?.pressure} hPa</p>
      <p>Wind: {wind?.speed} m/s</p>
      <p>Cloudiness: {clouds?.all}%</p>
    </div>
  );
}

export default WeatherDetails;
