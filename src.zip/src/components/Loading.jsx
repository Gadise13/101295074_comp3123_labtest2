
import React from 'react';

function Loading() {
  return <div className="loading">Loading...</div>;
}

export default Loading;
