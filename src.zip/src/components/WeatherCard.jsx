
import React from 'react';

function WeatherCard({ data }) {
  const { name, sys, weather, main } = data;
  const condition = weather?.[0];
  const iconUrl = condition ? `https://openweathermap.org/img/wn/${condition.icon}@2x.png` : null;

  return (
    <div className="weather-card">
      <h2>{name}, {sys?.country}</h2>
      <p>{condition?.description}</p>
      <p>{Math.round(main?.temp)}°C (feels like {Math.round(main?.feels_like)}°C)</p>
      {iconUrl && <img src={iconUrl} alt="Weather icon" />}
    </div>
  );
}

export default WeatherCard;
